import React from 'react';
import PromptGenerator from './components/PromptGenerator';

function App() {
  return <PromptGenerator />;
}

export default App;