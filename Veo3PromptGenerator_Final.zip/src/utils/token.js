// Token system utils
export const getToken = () => 3;